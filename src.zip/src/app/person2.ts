export class Person2 {
    jobtitle!: any;
    dateneedstoknow!: any;
    timeneedstobedone!: any;
    pickup!: any;
    pickup1!: any;
    pickupaddress!: any;
    pickupaddress1!: any;
    pickupaddress2!: any;
    pickupaddress3!: any;
    pickupaddress4!: any;
    dropoffaddress!: any;
    dropoffaddress1!: any;
    dropoffaddress2!: any;
    dropoffaddress3!: any;
    dropoffaddress4!: any;
    chooseprice!: any;
    cardnumber!: any;
    cvv!: any;
    cardexpiry!: any;
  }