import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mycontact',
  templateUrl: './mycontact.component.html',
  styleUrls: ['./mycontact.component.css']
})
export class MycontactComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
