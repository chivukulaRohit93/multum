import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myreviews',
  templateUrl: './myreviews.component.html',
  styleUrls: ['./myreviews.component.css']
})
export class MyreviewsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
