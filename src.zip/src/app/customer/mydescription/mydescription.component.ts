import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mydescription',
  templateUrl: './mydescription.component.html',
  styleUrls: ['./mydescription.component.css']
})
export class MydescriptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
