import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createacc',
  templateUrl: './createacc.component.html',
  styleUrls: ['./createacc.component.css']
})
export class CreateaccComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
