import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mypastjobs',
  templateUrl: './mypastjobs.component.html',
  styleUrls: ['./mypastjobs.component.css']
})
export class MypastjobsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
