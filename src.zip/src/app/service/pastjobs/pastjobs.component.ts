import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pastjobs',
  templateUrl: './pastjobs.component.html',
  styleUrls: ['./pastjobs.component.css']
})
export class PastjobsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
