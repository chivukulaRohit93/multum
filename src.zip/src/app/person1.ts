export class Person1 {
    username!: string;
    password!: string;
  }