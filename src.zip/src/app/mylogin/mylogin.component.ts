import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mylogin',
  templateUrl: './mylogin.component.html',
  styleUrls: ['./mylogin.component.css']
})
export class MyloginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
