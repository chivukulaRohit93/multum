import { MysearchPipe } from './mysearch.pipe';

describe('MysearchPipe', () => {
  it('create an instance', () => {
    const pipe = new MysearchPipe();
    expect(pipe).toBeTruthy();
  });
});
